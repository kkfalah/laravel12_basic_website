-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jan 10, 2026 at 08:02 AM
-- Server version: 8.4.7
-- PHP Version: 8.4.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `basic`
--

-- --------------------------------------------------------

--
-- Table structure for table `blogs`
--

DROP TABLE IF EXISTS `blogs`;
CREATE TABLE IF NOT EXISTS `blogs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `category_id` bigint UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `blogs_category_id_foreign` (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `blogs`
--

INSERT INTO `blogs` (`id`, `category_id`, `title`, `slug`, `description`, `image`, `created_at`, `updated_at`) VALUES
(1, 2, 'Why do need personal finance software', 'why-do-need-personal-finance-software', '<p>Personal finance software can help you manage your money more effectively and save on expenses. It can help you track your spending, set financial goals, and make informed financial decisions.</p><p>Personal finance software can also help you stay disciplined with your spending and make better financial decisions. When selecting the best free personal finance software, consider the following factors:</p><ul><li>Ease of Use: Look for an app that’s intuitive and easy to navigate. If it’s too complicated, you may not stick with it.</li><li>Mobile Access: If you want to manage your finances on the go, choose an app that’s available on mobile devices.</li><li>Integration with Accounts: Make sure the software can sync with your bank, credit card, and investment accounts to streamline tracking.</li></ul><h4><strong>\"Make sure you have financial intelligence… I don’t care if you have money or you don’t have money.”</strong></h4><h4><strong>– Daymond John</strong></h4><p><br></p><p><br></p>', 'blog/Why-do-need-personal-finance-software-20260107142732.png', '2026-01-07 09:41:52', '2026-01-08 06:49:31'),
(2, 3, 'Advantages of personal finance software', 'advantages-of-personal-finance-software', '<p>This type of software helps you track and manage your finances – including checking, savings, credit cards, and investments all in one place. When selecting the best free personal finance software, consider the following factors: Track Your Spending:</p><p>Free apps automatically track your spending, giving you a clear picture of where your money. Create Budgets: Budgeting becomes simple, allowing you to set spending limits in different categories and stick. Set Savings Goals: You can set and monitor savings goals for everything from vacations to emergency funds.</p>', 'blog/Advantages-of-personal-finance-software-20260107142723.png', '2026-01-07 09:42:49', '2026-01-07 10:27:24');

-- --------------------------------------------------------

--
-- Table structure for table `blog_categories`
--

DROP TABLE IF EXISTS `blog_categories`;
CREATE TABLE IF NOT EXISTS `blog_categories` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `blog_categories`
--

INSERT INTO `blog_categories` (`id`, `name`, `slug`, `created_at`, `updated_at`) VALUES
(1, 'General', 'general', NULL, NULL),
(2, 'Finance', 'finance', NULL, '2026-01-07 06:23:48'),
(3, 'Business', 'business', NULL, NULL),
(4, 'Technology', 'technology', NULL, NULL),
(5, 'Development', 'development', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
CREATE TABLE IF NOT EXISTS `cache` (
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
CREATE TABLE IF NOT EXISTS `cache_locks` (
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

DROP TABLE IF EXISTS `contacts`;
CREATE TABLE IF NOT EXISTS `contacts` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `name`, `email`, `message`, `created_at`, `updated_at`) VALUES
(1, 'Falah KK', 'kkfalah@gmail.com', 'test', '2026-01-08 07:37:48', '2026-01-08 07:37:48'),
(3, 'Falah', 'kkfalah@live.com', 'asdfsdfsd', '2026-01-08 08:21:11', '2026-01-08 08:21:11');

-- --------------------------------------------------------

--
-- Table structure for table `ctas`
--

DROP TABLE IF EXISTS `ctas`;
CREATE TABLE IF NOT EXISTS `ctas` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `ctas`
--

INSERT INTO `ctas` (`id`, `title`, `description`, `image`, `created_at`, `updated_at`) VALUES
(1, 'Start a new level of money management', 'Our finance apps and software are powerful tools for managing personal or business finances, helping users stay organized, track financial health, and make informed decisions.', 'cta/-20251229190450.png', NULL, '2025-12-29 15:04:50');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `faqs`
--

DROP TABLE IF EXISTS `faqs`;
CREATE TABLE IF NOT EXISTS `faqs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `question` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `answer` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `faqs`
--

INSERT INTO `faqs` (`id`, `question`, `answer`, `created_at`, `updated_at`) VALUES
(1, 'Is my financial data safe and secure?', 'Yes, this finance apps use bank-level encryption, multi-factor authentication, and other security measures to protect your sensitive information.', '2025-12-25 08:54:47', '2025-12-25 08:54:47'),
(2, 'Can I link multiple bank accounts and credit cards?', 'Yes, this finance apps use bank-level encryption, multi-factor authentication, and other security measures to protect your sensitive information.', '2025-12-25 08:57:33', '2025-12-25 08:57:33'),
(3, 'How does the app help me stick to my budget?', 'Yes, this finance apps use bank-level encryption, multi-factor authentication, and other security measures to protect your sensitive information.', '2025-12-25 08:57:49', '2025-12-25 08:57:49'),
(4, 'Can I track my investments with the app?', 'Yes, this finance apps use bank-level encryption, multi-factor authentication, and other security measures to protect your sensitive information.', '2025-12-25 08:58:03', '2025-12-25 08:58:03'),
(5, 'Is the app free, or are there subscription fees?', 'Yes, this finance apps use bank-level encryption, multi-factor authentication, and other security measures to protect your sensitive information.', '2025-12-25 08:58:27', '2025-12-25 08:58:27');

-- --------------------------------------------------------

--
-- Table structure for table `features`
--

DROP TABLE IF EXISTS `features`;
CREATE TABLE IF NOT EXISTS `features` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `features`
--

INSERT INTO `features` (`id`, `title`, `description`, `image`, `created_at`, `updated_at`) VALUES
(1, 'Expense Tracking', 'Allows users to record and categorize daily transactions such as income, expenses, bills, and savings.', 'features/Expense-Tracking-20251222122539.svg', '2025-12-22 08:25:39', '2025-12-22 08:30:59'),
(2, 'Budgeting Tools', 'Provides visual insights like graphs or pie charts to show how much is spent versus the budgeted amount.', 'features/Budgeting-Tools-20251222123218.svg', '2025-12-22 08:32:18', '2025-12-22 08:32:18'),
(3, 'Investment Tracking', 'For users interested in investing, finance apps often provide tools to track stocks, bonds or mutual funds.', 'features/Investment-Tracking-20251222123240.svg', '2025-12-22 08:32:40', '2025-12-22 08:32:40'),
(4, 'Tax Management', 'This tool integrate with tax software to help users prepare for tax season, deduct expenses, and file returns.', 'features/Tax-Management-20251222123304.svg', '2025-12-22 08:33:04', '2025-12-22 08:33:04'),
(5, 'Bill Management', 'Tracks upcoming bills, sets reminders for due dates, and enables easy payments via integration with online banking', 'features/Bill-Management-20251222123324.svg', '2025-12-22 08:33:24', '2025-12-22 08:33:24'),
(6, 'Security Features', 'Provides bank-level encryption to ensure user data and financial information remain safe, MFA and biometric logins.', 'features/Security-Features-20251222123346.svg', '2025-12-22 08:33:46', '2025-12-22 08:33:46');

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
CREATE TABLE IF NOT EXISTS `jobs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `queue` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint UNSIGNED NOT NULL,
  `reserved_at` int UNSIGNED DEFAULT NULL,
  `available_at` int UNSIGNED NOT NULL,
  `created_at` int UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
CREATE TABLE IF NOT EXISTS `job_batches` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mid_section_ones`
--

DROP TABLE IF EXISTS `mid_section_ones`;
CREATE TABLE IF NOT EXISTS `mid_section_ones` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `mid_section_ones`
--

INSERT INTO `mid_section_ones` (`id`, `title`, `description`, `image`, `created_at`, `updated_at`) VALUES
(1, 'It clarifies all strategic financial decisions', 'With this tool, you can say goodbye to overspending, stay on track with your savings goals, and say goodbye to financial worries. Get ready for a clearer view of your finances like never before!', 'sections/It-clarifies-all-strategic-financial-decisions-20251224112654.png', NULL, '2025-12-24 07:26:55');

-- --------------------------------------------------------

--
-- Table structure for table `mid_section_twos`
--

DROP TABLE IF EXISTS `mid_section_twos`;
CREATE TABLE IF NOT EXISTS `mid_section_twos` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_title1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_description1` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `sub_title2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_description2` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `mid_section_twos`
--

INSERT INTO `mid_section_twos` (`id`, `title`, `description`, `image`, `sub_title1`, `sub_description1`, `sub_title2`, `sub_description2`, `created_at`, `updated_at`) VALUES
(1, 'Get all your financial updates in one place', 'This feature ensures you can easily stay on top of your finances by consolidating all updates into a single dashboard.', 'sections/Get-all-your-financial-updates-in-one-place-20251224112641.png', 'Unified Dashboard', 'View all your accounts, transactions & investments in one central location. See every credit & debit transaction as it happens across all your accounts. Get a complete view of your expenses with expense categories.', 'Real-Time Updates', 'This feature ensures you can easily stay on top of your finances by consolidating all updates into a single dashboard. View all your accounts, transactions iew of your expenses with expense categories.', NULL, '2025-12-24 07:35:15');

-- --------------------------------------------------------

--
-- Table structure for table `mid_section_videos`
--

DROP TABLE IF EXISTS `mid_section_videos`;
CREATE TABLE IF NOT EXISTS `mid_section_videos` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `link` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video_link` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `mid_section_videos`
--

INSERT INTO `mid_section_videos` (`id`, `title`, `description`, `link`, `video_link`, `image`, `created_at`, `updated_at`) VALUES
(1, 'Its usability is simple and intuitive for users', 'It\'s a cloud-based accounting tool ideal for individuals & businesses to easily manage finances, invoices & payroll. Unlock the 3-step path to enhanced financial control.', '#', 'https://www.youtube.com/watch?v=fgZc7mAYIY8', 'sections/Its-usability-is-simple-and-intuitive-for-users-20251224180829.png', NULL, '2025-12-24 14:08:29');

-- --------------------------------------------------------

--
-- Table structure for table `mid_section_video_bottoms`
--

DROP TABLE IF EXISTS `mid_section_video_bottoms`;
CREATE TABLE IF NOT EXISTS `mid_section_video_bottoms` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `mid_section_video_bottoms`
--

INSERT INTO `mid_section_video_bottoms` (`id`, `title`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Connect Your Accounts', 'Link your bank, credit card or investment accounts to automatically track transactions and get a complete financial overview', NULL, '2025-12-25 06:56:56'),
(2, 'Set Budgets & Goals', 'Define your spending limits and savings goals for categories like groceries, bills or future investments to stay on track.', NULL, NULL),
(3, 'Monitor & Automate', 'Check your financial dashboard for regular updates and set up automatic payments or savings to simplify management.', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '0001_01_01_000000_create_users_table', 1),
(2, '0001_01_01_000001_create_cache_table', 1),
(3, '0001_01_01_000002_create_jobs_table', 1),
(4, '2025_12_20_161021_create_testimonials_table', 2),
(5, '2025_12_21_144447_create_sliders_table', 3),
(6, '2025_12_22_100217_create_titles_table', 4),
(7, '2025_12_22_111449_create_features_table', 5),
(8, '2025_12_24_093312_create_mid_section_ones_table', 6),
(9, '2025_12_24_110307_create_mid_section_twos_table', 7),
(11, '2025_12_24_174730_create_mid_section_videos_table', 8),
(12, '2025_12_25_103815_create_mid_section_video_bottoms_table', 9),
(13, '2025_12_25_122848_create_faqs_table', 10),
(14, '2025_12_29_082447_create_ctas_table', 11),
(15, '2025_12_30_104320_create_teams_table', 12),
(16, '2026_01_07_081423_create_blog_categories_table', 13),
(20, '2026_01_07_103149_create_blogs_table', 14),
(21, '2026_01_08_112708_create_contacts_table', 15);

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
CREATE TABLE IF NOT EXISTS `password_reset_tokens` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE IF NOT EXISTS `sessions` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('qPep83YK2Y73Y0NnVaw0ftX0YHCUrVhR7qXchLQw', 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoicDl0eG9PbWZna1ZwNHJjdDJ5ZEkxZE45cDY5TVM1bXh0S0I0SWdCaiI7czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6MTtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czozNzoiaHR0cDovLzEyNy4wLjAuMTo4MDAwL2FkbWluL2Rhc2hib2FyZCI7czo1OiJyb3V0ZSI7czo5OiJkYXNoYm9hcmQiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19', 1767879261);

-- --------------------------------------------------------

--
-- Table structure for table `sliders`
--

DROP TABLE IF EXISTS `sliders`;
CREATE TABLE IF NOT EXISTS `sliders` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `link` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sliders`
--

INSERT INTO `sliders` (`id`, `title`, `description`, `image`, `link`, `created_at`, `updated_at`) VALUES
(1, 'Manage your finances more effectively.', 'Track your daily finances automatically. Manage your money in a friendly & flexible way, making it easy to spend guilt-free.', 'sliders/Manage-your-finances-more-effectively.-20251224102751.png', '#', '2025-12-21 11:12:00', '2025-12-24 06:27:51');

-- --------------------------------------------------------

--
-- Table structure for table `teams`
--

DROP TABLE IF EXISTS `teams`;
CREATE TABLE IF NOT EXISTS `teams` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `position` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `teams`
--

INSERT INTO `teams` (`id`, `name`, `position`, `image`, `created_at`, `updated_at`) VALUES
(1, 'Michael Chen', 'Chief Executive Officer', 'team/Michael-Chen-20251230111708.png', '2025-12-30 06:57:40', '2025-12-30 07:17:08'),
(2, 'Alex Jonny', 'Head of Product', 'team/Alex-Jonny-20251230111719.png', '2025-12-30 07:03:43', '2025-12-30 07:17:20'),
(3, 'William Smith', 'Lead Software Engineer', 'team/William-Smith-20251230111643.png', '2025-12-30 07:04:00', '2025-12-30 07:16:44'),
(4, 'Frederick Taylor', 'Data Security Officer', 'team/Frederick-Taylor-20251230111634.png', '2025-12-30 07:04:18', '2025-12-30 07:16:34');

-- --------------------------------------------------------

--
-- Table structure for table `testimonials`
--

DROP TABLE IF EXISTS `testimonials`;
CREATE TABLE IF NOT EXISTS `testimonials` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `position` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_ci,
  `rating` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `testimonials`
--

INSERT INTO `testimonials` (`id`, `name`, `position`, `image`, `message`, `rating`, `created_at`, `updated_at`) VALUES
(1, 'Tovino Thomas', 'Actor', 'testimonials/Tovino-Thomas-20251220182254.jpeg', 'This app transformed my budgeting! It has been a clear view longer have to worry of my It has been success expenses and savings goals.', '4', '2025-12-20 14:22:54', '2025-12-21 07:11:57'),
(2, 'Fahad Fasil', 'Actor', 'testimonials/Fahad-Fasil-20251221091242.jpg', 'Having all my accounts in one place gives me complete control over my money. So user-friendly and helpful! Highly recommend!', '2', '2025-12-21 05:12:42', '2025-12-21 07:11:20'),
(4, 'Dulqar Salman', 'Actor', 'testimonials/Dulqar-Salman-20251221122910.jpeg', 'Having all my accounts in one place gives me complete control over my money. So user-friendly and helpful! Highly recommend!', '3', '2025-12-21 08:29:10', '2025-12-21 08:29:10'),
(5, 'Falah KK', 'Developer', '', 'Having all my accounts in one place gives me complete control over my money. So user-friendly and helpful! Highly recommend!', '5', '2025-12-21 08:29:37', '2025-12-21 08:29:37');

-- --------------------------------------------------------

--
-- Table structure for table `titles`
--

DROP TABLE IF EXISTS `titles`;
CREATE TABLE IF NOT EXISTS `titles` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `features` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `testimonials` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `answers` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `titles`
--

INSERT INTO `titles` (`id`, `features`, `testimonials`, `answers`, `created_at`, `updated_at`) VALUES
(1, 'Features that make spending smarter', 'Don\'t take our word for it, check user reviews', 'Find answers to all questions below', NULL, '2025-12-22 06:56:36');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `role` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `status` int NOT NULL DEFAULT '1',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `photo`, `phone`, `address`, `role`, `status`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Falah KK', 'kkfalah@gmail.com', NULL, '$2y$12$Dd0YE.hsEpT7KnddJL.TWeG7XVUUQBB7bboe704zf9/c8LolARLZa', 'users/Falah-KK-20251220111233.jpeg', '0557713759', 'Dubai', 'user', 1, 'L0tq7M2BoLM4w3OPXsHELTgIbh77k863uT6Nz1zK95S3DDEHohHXjwRq8Gu0', '2025-12-18 06:57:53', '2025-12-20 09:25:28'),
(2, 'Writer', 'writer@gmail.com', NULL, '$2y$12$2dUwD.Y6Z8ZYhU5v7eRRD.t1DMesaTULqQ3Q.QXYdj1m3e4bKl/4G', NULL, NULL, NULL, 'user', 1, 'eX69eN0RLgwJktOW22kQnKZivm95wj2KngfSFXSWdCqqC0DCYn3R4joYgqtO', '2025-12-18 09:24:51', '2025-12-18 09:37:01');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
